package softuni.jsonexercise.servicies;

public interface SaleService {
    void seedData();
}
