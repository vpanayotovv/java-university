package oldPackeges.Vehicles;

public class Bus extends Vehicles {
    public Bus(double fuel, double fuelConsumption,int tankCapacity) {
        super(fuel, fuelConsumption,tankCapacity);
    }

    @Override
    public void drive(double distance) {
        super.drive(distance);
    }


}