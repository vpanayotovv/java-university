package motocrossWorldChampionship.core;

import motocrossWorldChampionship.core.interfaces.Engine;

public class EngineImpl implements Engine {
    @Override
    public void run() {

    }
}
